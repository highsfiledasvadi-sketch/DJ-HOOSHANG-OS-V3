package com.djhooshang.robot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private FaceView face;
    private TextView status;
    private TextToSpeech tts;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private boolean permissionAsked = false;
    private long lastMotion = 0;
    private long lastWake = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String mood = "happy";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 20, 24, 20);
        root.setBackgroundColor(Color.rgb(7,19,35));

        TextView title = new TextView(this);
        title.setText("DJ HOOSHANG");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 55));

        face = new FaceView(this);
        root.addView(face, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setText("Hey! I'm ready.");
        status.setTextColor(Color.rgb(180,225,255));
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 48));

        Button hello = new Button(this);
        hello.setText("Say hello");
        root.addView(hello, new LinearLayout.LayoutParams(-1, 55));
        hello.setOnClickListener(v -> speak("Hello! I'm DJ Hooshang. It's nice to see you!"));

        Button voice = new Button(this);
        voice.setText("Tap to talk / Wake word");
        root.addView(voice, new LinearLayout.LayoutParams(-1, 55));
        voice.setOnClickListener(v -> startListening());

        setContentView(root);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int language = tts.setLanguage(Locale.US);
                tts.setSpeechRate(0.92f);
                if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                    setStatus("Install an English voice in Android Text-to-speech settings.");
                }
            }
        });

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer == null) setStatus("Motion sensor not found on this phone.");
        setMood("happy", "Hey! I'm ready.");
    }

    private void speak(String words) {
        if (tts != null) tts.speak(words, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void setStatus(String message) { if (status != null) status.setText(message); }

    private void setMood(String newMood, String message) {
        mood = newMood;
        if (face != null) face.setMood(newMood);
        setStatus(message);
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;
        float x = event.values[0], y = event.values[1], z = event.values[2];
        float magnitude = (float)Math.sqrt(x*x + y*y + z*z);
        long now = System.currentTimeMillis();

        // A sudden movement or strong rotation makes the robot dizzy.
        if ((Math.abs(magnitude - SensorManager.GRAVITY_EARTH) > 3.2f ||
             Math.abs(x) > 7.0f || Math.abs(y) > 7.0f) && now - lastMotion > 3500) {
            lastMotion = now;
            setMood("dizzy", "Whoa! I'm getting dizzy!");
            speak("Whoa! I'm getting dizzy!");
            handler.removeCallbacks(recoverRunnable);
            handler.postDelayed(() -> {
                // Lying flat means the phone has settled after the movement.
                if (Math.abs(z) > 7.0f && Math.abs(x) < 5.5f && Math.abs(y) < 5.5f) {
                    setMood("angry", "Hey! What was that?");
                    speak("Hey! What was that?");
                    handler.postDelayed(recoverRunnable, 3500);
                } else {
                    setMood("happy", "I'm okay now. Let's talk!");
                    speak("I'm okay now. Let's talk!");
                }
            }, 1300);
        }
    }

    private final Runnable recoverRunnable = () -> {
        setMood("happy", "I'm okay now. Let's talk!");
        speak("I'm okay now. Let's talk!");
    };

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Speech recognition is not available on this phone.");
            speak("Speech recognition is not available.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 42);
            return;
        }
        if (recognizer != null) { try { recognizer.destroy(); } catch (Exception ignored) {} }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle params) { setStatus("Listening... say Hey DJ Hooshang."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rmsdB) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() { setStatus("Thinking..."); }
            public void onError(int error) { listening = false; setStatus("Tap to talk again."); }
            public void onResults(Bundle results) {
                listening = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String said = (matches != null && !matches.isEmpty()) ? matches.get(0).toLowerCase(Locale.US) : "";
                if (said.contains("hey dj hooshang") || said.contains("hey dj") || said.contains("hey hooshang")) {
                    setMood("happy", "Yes? I'm listening!");
                    speak("Yes? I'm listening!");
                } else if (said.contains("hello") || said.contains("hi")) {
                    setMood("happy", "Hello! How are you?");
                    speak("Hello! How are you?");
                } else {
                    setStatus("I heard: " + (said.isEmpty() ? "something" : said));
                    speak("Sorry, I didn't catch that. Please say it again.");
                }
            }
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(intent);
        listening = true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 42 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else if (requestCode == 42) setStatus("Microphone permission is needed for voice commands.");
    }

    @Override protected void onResume() {
        super.onResume();
        if (sensorManager != null && accelerometer != null)
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override protected void onPause() {
        super.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (recognizer != null) { try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) {} recognizer = null; }
        listening = false;
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
