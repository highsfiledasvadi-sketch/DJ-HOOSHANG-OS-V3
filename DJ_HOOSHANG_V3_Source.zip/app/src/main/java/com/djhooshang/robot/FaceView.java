package com.djhooshang.robot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.os.Handler;
import android.os.Looper;

public class FaceView extends View {
    private final Paint p = new Paint(3);
    private String mood = "happy";
    private float lookX = 0, lookY = 0;
    private boolean blink = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable blinkTask = new Runnable() {
        public void run() { blink = true; invalidate(); h.postDelayed(() -> { blink = false; invalidate(); h.postDelayed(this, 2600 + (long)(Math.random()*1800)); }, 150); }
    };

    public FaceView(Context c) {
        super(c);
        h.postDelayed(blinkTask, 1200);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setMood(String m) { mood = m; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), ht = getHeight();
        float cx = w/2f, cy = ht/2f;
        float eyeW = Math.min(w*0.29f, 190), eyeH = Math.min(ht*0.48f, 220);
        float gap = Math.min(w*0.08f, 48);
        if ("dizzy".equals(mood)) {
            c.save(); c.rotate((System.currentTimeMillis()/9)%360, cx, cy);
        }
        drawEye(c, cx-gap/2-eyeW/2, cy, eyeW, eyeH);
        drawEye(c, cx+gap/2+eyeW/2, cy, eyeW, eyeH);
        if ("dizzy".equals(mood)) c.restore();
        if ("angry".equals(mood)) {
            p.setColor(0xFF071323); p.setStrokeWidth(15); p.setStyle(Paint.Style.STROKE);
            c.drawLine(cx-eyeW-gap/2, cy-eyeH*.48f, cx-gap*.2f, cy-eyeH*.28f, p);
            c.drawLine(cx+gap*.2f, cy-eyeH*.28f, cx+eyeW+gap/2, cy-eyeH*.48f, p);
            p.setStyle(Paint.Style.FILL);
        }
        if ("dizzy".equals(mood)) {
            p.setColor(0xFFFFD166); p.setTextSize(42); p.setTextAlign(Paint.Align.CENTER);
            c.drawText("✦   ✦", cx, cy-eyeH*.75f, p);
        }
        postInvalidateDelayed(70);
    }

    private void drawEye(Canvas c, float x, float y, float ew, float eh) {
        RectF r = new RectF(x-ew/2, y-eh/2, x+ew/2, y+eh/2);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF20BFFF);
        if (blink) c.drawRoundRect(new RectF(r.left, y-5, r.right, y+5), 12, 12, p);
        else c.drawRoundRect(r, ew*.34f, ew*.34f, p);
        if (!blink && !"dizzy".equals(mood)) {
            p.setColor(0xFFB8F1FF);
            c.drawCircle(x+ew*.12f, y-eh*.17f, ew*.075f, p);
        }
    }
}
